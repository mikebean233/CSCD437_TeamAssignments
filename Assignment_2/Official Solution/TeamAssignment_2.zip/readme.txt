Assignment 2

Team: The Wise Guys
Members:
- Michael Peterson
- Matt McGee
- Heath Knickerbocker


This version takes multiple stages, the first stage stores the source in a static char array.  This program is built and executed and it produces source with the characters in the static char array converted to integers.  The second stage is the final source for program which will produce a copy of it's self as the output.

(for this submission only the source for the second stage is provided although the first stage source can be access from https://github.com/mikebean233/CSCD437_TeamAssignments/tree/master/Assignment_2/MichaelPeterson/Solution%202 )


Building and running: Run the command "make" from the linux shell.

Note: My solution is a blatant rip off of the solution presented in the handout.
- Michael Peterson