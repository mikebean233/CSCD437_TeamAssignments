CSCD437, Assignment 6, "Defend your code"

Team members:
Matt McGee
Heath Knickerbocker
Michael Peterson

This software is designed to be run only on a Linux system, and compiled with gcc version 4 or greater.


Building:
   Java:
     make clean
     make

   C:
     make clean
     make
     make test

Running
   Java:
     make run

   C:
     make run
     make run_test
